import logging
from datamodel.search.Paichunw_datamodel import PaichunwLink, OnePaichunwUnProcessedLink
from spacetime.client.IApplication import IApplication
from spacetime.client.declarations import Producer, GetterSetter, Getter
from lxml import html,etree
import lxml
import re, os
from time import time
from uuid import uuid4

from urlparse import urlparse, parse_qs
from uuid import uuid4

# store all the global varaibles
from function import save_data, load_data
import json

# loading global variable
fileName = 'data.txt'
pagesCount, MaxOutputLink, invalidCount, subDomain = load_data(fileName)

logger = logging.getLogger(__name__)
LOG_HEADER = "[CRAWLER]"

@Producer(PaichunwLink)
@GetterSetter(OnePaichunwUnProcessedLink)
class CrawlerFrame(IApplication):
    app_id = "Paichunw"

    def __init__(self, frame):
        self.app_id = "Paichunw"
        self.frame = frame

    def initialize(self):
        self.count = 0
        links = self.frame.get_new(OnePaichunwUnProcessedLink)
        if len(links) > 0:
            print "Resuming from the previous state."
            self.download_links(links)
        else:
            l = PaichunwLink("http://www.ics.uci.edu/")
            print l.full_url
            self.frame.add(l)

    def update(self):
        unprocessed_links = self.frame.get_new(OnePaichunwUnProcessedLink)
        if unprocessed_links:
            self.download_links(unprocessed_links)

    def download_links(self, unprocessed_links):
	global invalidCount
	global pagesCount
	global subDomain

        for link in unprocessed_links:
            if not is_valid(link.full_url):
                invalidCount += 1
                print "----->>>", link.full_url, " is not a valid URL"
            else:
                print "Get a link to download:", link.full_url
                downloaded = link.download()
                links = extract_next_links(downloaded)

                for oneLink in links:
                    if is_valid(oneLink):
                        self.frame.add(PaichunwLink(oneLink))

                # subDomain
                parsed = urlparse(link.full_url)
                if parsed.netloc in subDomain:
                    subDomain[parsed.netloc]+=1
                else:
                    subDomain[parsed.netloc]=1

                print "----->> Finished this URL"

                # calculate how many pages are visited
                pagesCount += 1
                print "--->> Total: ", pagesCount
                
		if pagesCount > 3000:
                    writeFile()
                    print '-----END'

        print('---- completed all crawling')
        writeFile()

    def shutdown(self):
        writeFile()
        save_data(fileName, pagesCount, MaxOutputLink, invalidCount, subDomain)
        print (
            "Time time spent this session: ",
            time() - self.starttime, " seconds.")
    
def extract_next_links(rawDataObj):
    outputLinks = []
    '''
    rawDataObj is an object of type UrlResponse declared at L20-30
    datamodel/search/server_datamodel.py
    the return of this function should be a list of urls in their absolute form
    Validation of link via is_valid function is done later (see line 42).
    It is not required to remove duplicates that have already been downloaded. 
    The frontier takes care of that.
    
    Suggested library: lxml
    '''
    global MaxOutputLink

    if rawDataObj.is_redirected:
        parsed = urlparse(rawDataObj.final_url)
    else:
        parsed = urlparse(rawDataObj.url)

    url_prefix = parsed.scheme + '://' + parsed.netloc

    if len(rawDataObj.content)==0:
        return outputLinks

    doc = lxml.html.fromstring(rawDataObj.content)  

    links = doc.xpath('//a/@href')

    for link in links:
        outputLink = ''

        if link.startswith('/'):
            outputLink = url_prefix + link
        elif link.startswith('http') or link.startswith('https'):
            outputLink = link
        elif link.startswith('#'):
            pass
        else:
            outputLink = url_prefix + '/' + link
        
	if outputLink:
            outputLinks.append(outputLink)

    print "there are totally", len(outputLinks), "of outputLinks"

    if len(outputLinks) > MaxOutputLink[1]:
        MaxOutputLink = [rawDataObj.url, len(outputLinks)]

    return outputLinks

def is_valid(url):
    '''
    Function returns True or False based on whether the url has to be
    downloaded or not.
    Robot rules and duplication rules are checked separately.
    This is a great place to filter out crawler traps.
    '''
    hash = set()
    
    # filter
    if 'wics.ics.uci.edu/events' in url.lower():
        return False

    parsed = urlparse(url)

    # filter
    if parsed.scheme not in set(["http", "https"]):
        return False

    query = parsed.query

    # filter
    if 'login' in query.lower() or 'edit' in query.lower():
        return False

    paths = parsed.path.split('/')

    # filter
    if len(paths) > 10 or len(query) > 30:
        return False

    for path in paths:
        if "calendar" in path: 
            return False
        elif '..' in path or 'mailto' in path or '@' in path or 'brownbags' in path:
            return False
        elif path in hash:
            return False
        else:
            hash.add(path)

    try:
        return ".ics.uci.edu" in parsed.hostname \
            and not re.match(".*\.(css|js|bmp|gif|jpe?g|ico" + "|png|tiff?|mid|mp2|mp3|mp4"\
            + "|wav|avi|mov|mpeg|ram|m4v|mkv|ogg|ogv|pdf" \
            + "|ps|eps|tex|ppt|pptx|doc|docx|xls|xlsx|names|data|dat|exe|bz2|tar|msi|bin|7z|psd|dmg|iso|epub|dll|cnf|tgz|sha1" \
            + "|thmx|mso|arff|rtf|jar|csv"\
            + "|rm|smil|wmv|swf|wma|zip|rar|gz|pdf)$", parsed.path.lower())

    except TypeError:
        print ("TypeError for ", parsed)
        return False

def writeFile():
    file = open("analysisFile.txt","w") 
    for key in subDomain.keys():
        file.write("subDomain: " + key + "\n")
        file.write("Number of URLs: " + str(subDomain[key]) + "\n")

    file.write("Number of invalid links: " + str(invalidCount) + "\n")
    file.write(MaxOutputLink[0]+" has the most number of outgoing links: " + str(MaxOutputLink[1]))
    file.close()
